Open the terminal and navigate to the working directory
q1. enter "g++ -o Assgn1q1Src-ArnabMandal Assgn1q1Src-ArnabMandal.cpp"
    enter "./Assgn1q1Src-ArnabMandal"

q2. enter "g++ Assgn1q2Src-ArnabMandal.cpp -o q2"
    enter "./q2"

q3. enter "more /proc/cpuinfo"
    enter "lscpu"

q4. refer to q4 instructions

q5. refer to q5 instructions

q6. refer to q6 instructions

q7. refer to q7 instructions